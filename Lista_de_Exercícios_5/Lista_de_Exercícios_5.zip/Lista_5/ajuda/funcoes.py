def media(amostra):
  """""
    Função genérica para a média aritmética.
  """""

  return sum(amostra) / len(amostra)


def mediageom(x:float, y:float):
    """""
    Função genérica para a média geométrica entre dois números.
    x - número float 
    y - número float

    """""
    
    produto = x*y
    
    return (pow(produto, 1/2))

def fatorial(n:int):

    """""
    Função genérica para o cálculo do fatorial de um número.

    x - número inteiro

    """""


    produto = n
    contador = n -1

    for i in range(1,n-1):
        produto = produto * contador
        contador -= 1

    return produto