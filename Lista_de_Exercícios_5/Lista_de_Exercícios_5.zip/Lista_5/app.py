
print ('{:>50}'.format('Seja Bem-Vindo! \n'))

print("Esse programa realiza o cálculo de algumas operações matemáticas. \n")

print("Abaixo é apresentado o número correspondente as operações disponíveis: ")

print("1 - Média aritmética entre vários números;")
print("2 - Média geométrica entre dois números;")
print("3 - Fatorial de um número inteiro positivo. \n")


from ajuda.funcoes import media, mediageom, fatorial


while True:

    prompt = input("Informe o número que acompanha a operação ou s para sair: ")
    
    if prompt.lower()== "s":
        break

    elif prompt.isnumeric():
        numero = int(float(prompt))

        if numero == 1:
            lista = []   
            
            while True:
                a = input("Digite o número desejado ou s para sair: ")
                if a.lower() == "s":
                    break
                elif a.isnumeric():
                    a = float(a)
                    lista.append(a)
                    resultado = media(lista)  
                           
                else:
                    print("Essa entrada não é válida.Tente novamente!")
                    continue
            
            if len(lista) == 0:
                print("Nenhum número foi informado. Portanto não foi possível concluir a operação. ")
            else:
                print(f"A média aritmética é igual a {resultado:.2f}.")
                continue
            
        parar = True
        if numero == 2: 

            while True:
                lista = [] 

                x = input("Digite o primeiro número ou s para sair: ")

                if x.lower() == "s":
                    break

                if x.isnumeric():
                    lista.append(x)
                
                    while True:
                        y = input("Digite o segundo número ou s para sair: ")
                        if y.isdigit():
                            lista.append(y)

                            geom = mediageom(float(x), float(y))
                            
                            print(f"A média geométrica dos números digitados é igual a {geom:.2f}.")
                            parar = True
                            break 

                        if y.lower() == "s":
                            parar = True
                            break 

                        else:
                            print("Essa entrada não é válida. Tente novamente!")
                            continue

                if parar:
                    break

                else:
                    print("Essa entrada não é válida. Tente novamente!")
                    continue
 
            if len(lista) <= 1:
                print("Essa operação precisa de dois argumentos. Portanto não foi possível conclui-lá.")

            
        parar = True
        if numero == 3:
            while True:
                lista_2 = []
                b = input("Digite o número (inteiro e positivo) desejado ou s para sair: ")
                lista_2.append(b)

                if b.isnumeric():
                    if isinstance(int(b), int) and int(b) >0:
                        fator = int(b)
                        resultad_fatorial = fatorial(fator)
                
                    print(f"O fatorial de {b} é igual a {resultad_fatorial}.")
                    parar = True
                    break 
        
                elif  b.lower() == "s":
                    parar = True
                    break

                else:
                    print("Essa entrada não é válida. Tente novamente!")
                    continue
        
            if lista_2 == ["s"]:
                print("Nenhum número foi informado. Não foi possível concluir a operação.")
         
        else:
            print("Essa entrada não é válida. Tente novamente!")
        continue
    
    else:
        print("Essa entrada não é válida. Tente novamente!")
        continue
    


 

